// let arr=[0,1,2,3];

// arr.forEach(function(params) {
//     console.log(params);
// })
/*
const persona={
    "nombre":"jose",
    "edad":35,
    "dni":40000000
}
console.log(persona.dni)
let prod=["arroz", "papa"];
let stock=[8,20];
let precio=[1500,4000];

for (let i = 0; i < prod.length; i++) {
   console.log("Del producto "+ prod[i]+ " tengo "
    + stock[i]+ " unidades que valen c/u $"+ precio[i]);
}
*/
/*
const producto={
    "nombre":"arroz",
    "cantidad":35,
    "precio":1500
}

console.log("Del producto "+ producto.nombre + " tengo "
    + producto.cantidad + " unidades que valen c/u $"+ producto.precio);

*/
const producto = [{
    nombre: "arroz",
    cantidad: 35,
    precio: 1500
},
{
    nombre: "papa",
    cantidad: 20,
    precio: 4000
},
{
    nombre: "limon",
    cantidad: 40,
    precio: 2000,
}

]
//SECTION
//DIV. CARD
//    IMG
//   NOMBRE
//   PRECIO
//DIV
///SECTION

/*
for (let i = 0; i < array.length; i++) {
    
    CARD=  '<div class="card">
    <img id="i" src="" alt="">
    <p>nombre</p>
    <p>`Precio${producto[0].precio}`</p>
        </div>'
    SECCTION=QUERY.APPENDCHILD(card)
    
}

/*
let li=document.createElement("li")

document.querySelector("div ul").

*/


console.log(producto);
/*
let yerba = {
    nombre: "yerba",
    cantidad: 10,
    precio: 7000
}
producto.push(yerba)
producto.pop(yerba)
console.log(producto)*/

console.log(producto[2].cantidad);
producto[2].cantidad--
console.log(producto[2].cantidad);

/*document.querySelector("ul li").innerHTML=`El producto ${producto[0].nombre} tiene un stock de ${producto[0].cantidad}`
document.querySelector("input").innerHTML="";
function resetForm(params) {
    document.querySelector("input").innerHTML="";
}*/


//daiana fernandes, salto de pagina a un elemento en particular desde el index.

    document.querySelector(".contenedor").setAttribute('id','idAgregadoDesdeJS')



console.log(document.querySelector(".contenedor"))